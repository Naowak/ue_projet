package demo;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import weka.core.Instances;
import weka.classifiers.Classifier;
import weka.classifiers.bayes.BayesNet;
import weka.classifiers.bayes.NaiveBayesUpdateable;
import weka.classifiers.bayes.net.estimate.SimpleEstimator;
import weka.classifiers.evaluation.Evaluation;
import weka.classifiers.functions.MultilayerPerceptron;
import weka.classifiers.lazy.IBk;
import weka.classifiers.meta.ClassificationViaRegression;
import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.rules.DecisionTable;
import weka.classifiers.rules.ZeroR;
import weka.classifiers.trees.REPTree;
import weka.filters.Filter;
import weka.filters.supervised.attribute.Discretize;

// Link to javadoc: http://weka.sourceforge.net/doc.stable/

public class testWeka {

	public static void main(String args[]) {
		BufferedReader reader;
		try {
			System.out.println("ouverture 1");
			reader = new BufferedReader(new FileReader("arffFiles/test1.arff"));

			Instances learn = new Instances(reader);
			reader.close();
			// setting class attribute
			learn.setClassIndex(learn.numAttributes() - 1);

			System.out.println("ouverture 2");
			reader = new BufferedReader(new FileReader("arffFiles/test2.arff"));

			Instances test = new Instances(reader);
			reader.close();
			// setting class attribute
			test.setClassIndex(test.numAttributes() - 1);
			Instances resolv = new Instances(test);
			MultilayerPerceptron cla = new MultilayerPerceptron();

			FilteredClassifier fc = new FilteredClassifier();

			fc.setClassifier(cla);
			System.out.println("Apprentissage");
			cla.buildClassifier(learn);

			/*Evaluation eval = new Evaluation(learn);
			eval.evaluateModel(cla, test);
			System.out.println(eval.toSummaryString("\nResults\n======\n",
					false));*/
			
			for (int i = 0; i < test.numInstances(); i++) {
				double pred = cla.classifyInstance(test.instance(i));
				resolv.instance(i).setClassValue(pred);
				/*System.out.print("ID: " + resolv.instance(i).value(0));
				System.out.print(", actual: "
						+ test.classAttribute().value(
								(int) test.instance(i).classValue()));
				System.out.println(", predicted: " 
						+ resolv.classAttribute().value((int) pred));*/
				//System.out.println(", distrib: " + cla.distributionForInstance(test.instance(i)));
				//System.out.println(pred + " -> " + test.classAttribute().value((int) pred));
				//System.out.println("Actual: " + test.instance(i).attribute(test.numAttributes()-1).getLowerNumericBound() + " - Predicted: " + pred);
				double cold = test.instance(i).classValue();
				double cnew = resolv.instance(i).classValue();
				System.out.println(test.instance(i).classValue() + " <=> " + resolv.instance(i).classValue() + " .... " + Math.abs(cold-cnew)/cold);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
