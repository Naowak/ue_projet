package demo;
import java.io.FileNotFoundException;
import java.io.IOException;

import simulator.SolarPanelSimulator;


public class Test002 {

	public static void main(String[] args) {
		try {
			SolarPanelSimulator sNL = SolarPanelSimulator.loadSimulator("models/test1NL.model");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
