package simulator;
import java.io.*;
import java.util.*;
import java.util.Map.Entry;
import java.text.*;

/**
 * Ce fichier contient les m�thode permettant de cr�er les fichiers de donn�es
 * qui sont utilis�s par Weka
 **/
public class OpenData {
	
	/**
	 * Cr�� un fichier ARFF contenant les donn�es contenues dans le fichier
	 * pass� en param�tre.
	 * 
	 * @param data
	 *            HashMap contenant les donn�es
	 * @param file_name
	 *            Nom du fichier .arff qui va �tre cr��
	 * @param colname
	 *            Nom de la colonne qui sera
	 * @param linear
	 *            Si true, les donn�es vont �tre filtr�es
	 * @throws Exception
	 */
	public static void createARFF(Map<Integer, Map<String, Double>> data,
			String file_name, String colname, boolean linear) throws Exception {

		List<String> parametres = input_parameters(colname);
		if (linear) {
			int filtre[] = {1, 2, 3, 4, 5, 6, 7, 8, 68, 8, 7, 6, 5, 4, 3, 2, 1};
			data = DataWork.filtrage_data(data, filtre);
		}
		parse_and_write(file_name, data, parametres);

	}


	/**
	 * @param colname
	 * @return
	 */
	public static List<String> input_parameters(String colname) {
		List<String> parametre = new ArrayList<String>();
		parametre.add("ID");
		parametre.add("TIME");
		parametre.add("CPT_DEBI");
		parametre.add("TEMPERATURE");
		parametre.add("DRAI");
		parametre.add("PYRA");
		parametre.add("VENT");
		parametre.add("TAIR");
		// parametre.add("RAIN");
		parametre.add("Z_01");
		parametre.add("Z_02");
		parametre.add("Z_03");
		parametre.add("Z_04");
		parametre.add("Z_05");
		parametre.add("L_W1");
		parametre.add("T_W1");
		parametre.add("T_04");
		parametre.add("T_03");
		parametre.add("T_02");
		parametre.add("T_01");
		parametre.add("T_05");
		parametre.add("WSPD");
		parametre.add("CONDITION");
		parametre.add("UP01");
		parametre.add("PMP1");
		// parametre.add("P_01");
		// parametre.add("P_02");
		// parametre.add("P_03");
		parametre.add("RENDEMENT");

		if (parametre.remove(colname))
			parametre.add(colname);

		String input = "0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24";
		String[] p = input.split(" ");
		List<String> retour = new ArrayList<String>();
		for (int i = 0; i < p.length; ++i) {
			retour.add(parametre.get(Integer.parseInt(p[i])));
		}
		return retour;
	}

	/**
	 * M�thode qui cr�er un fichier .arff pr�t � �tre utilis� par la biblioth�que weka
	 * @param name_file
	 * @param data
	 * @param parametre
	 * @throws Exception
	 */
	public static void parse_and_write(String name_file,
			Map<Integer, Map<String, Double>> data, List<String> parametre)
			throws Exception {
		// On prépare le fichier dans lequel on écrit

		PrintWriter writer = new PrintWriter(name_file, "UTF-8");

		writer.println("@relation SuniAgri");
		writer.println("");

		int nb_parametre = parametre.size();

		for (int i = 0; i < nb_parametre; ++i)
			writer.println("@attribute " + parametre.get(i) + " numeric");

		writer.println("");
		writer.println("@data");

		// for(HashMap.Entry<Integer, Map<String, Double>> entry :
		// data.entrySet())

		for (Entry<Integer, Map<String, Double>> entry : data.entrySet()) {
			String separateur = "";
			for (int i = 0; i < nb_parametre; ++i) {
				if (parametre.get(i) == "TIME") {
					// Parametre TIME
					long time = entry.getKey();
					Date date = new Date(time * 1000);
					DateFormat formatter = new SimpleDateFormat("HH:mm:ss");
					String dateFormatted = formatter.format(date);
					int hours = Integer.parseInt(dateFormatted.substring(0, 2));
					int minutes = Integer.parseInt(dateFormatted
							.substring(3, 5));
					int seconds = Integer.parseInt(dateFormatted
							.substring(6, 8));
					int day_time = hours * 3600 + minutes * 60 + seconds;
					writer.print(separateur + day_time);
				} else if (parametre.get(i) == "RENDEMENT") {
					// Parametre RENDEMENT
					try {
						double r = entry.getValue().get("P_01")
								+ entry.getValue().get("P_02")
								+ entry.getValue().get("P_03");
						writer.print(separateur + r);
					} catch (NullPointerException e) {
						writer.print(separateur + "?");
					}
				} else if (parametre.get(i) == "ID"){
					writer.print(separateur + entry.getKey());
				} else {
					try {
						if (entry.getValue().get(parametre.get(i)) == null) {
							throw new NullPointerException();
						}
						writer.print(separateur
								+ entry.getValue().get(parametre.get(i)));
					} catch (NullPointerException e) {
						writer.print(separateur + "?");
					}
				}
				separateur = ",";
			}
			writer.println("");
		}

		writer.close();

	}


	public static List<String> getListParam(String gessCol) {
		List<String> parametre = new ArrayList<String>();
		parametre.add("ID");
		parametre.add("TIME");
		parametre.add("CPT_DEBI");
		parametre.add("TEMPERATURE");
		parametre.add("DRAI");
		parametre.add("PYRA");
		parametre.add("VENT");
		parametre.add("TAIR");
		// parametre.add("RAIN");
		parametre.add("Z_01");
		parametre.add("Z_02");
		parametre.add("Z_03");
		parametre.add("Z_04");
		parametre.add("Z_05");
		parametre.add("L_W1");
		parametre.add("T_W1");
		parametre.add("T_04");
		parametre.add("T_03");
		parametre.add("T_02");
		parametre.add("T_01");
		parametre.add("T_05");
		parametre.add("WSPD");
		parametre.add("CONDITION");
		parametre.add("UP01");
		parametre.add("PMP1");
		// parametre.add("P_01");
		// parametre.add("P_02");
		// parametre.add("P_03");
		parametre.add("RENDEMENT");

		if (parametre.remove(gessCol))
			parametre.add(gessCol);

		return parametre;
	}
}