package simulator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import weka.classifiers.Classifier;
import weka.classifiers.functions.MultilayerPerceptron;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Remove;

/**
 * SolarPanelSimulator est une class boite noire qui cr�er et utilise le model
 * MultilayerPerceptron de Weka. La cr�ation et l'utilisation de cette class
 * simulateur est possible de plusieur mani�re: En utlisant un fichier .ser
 * contenant les donn�es ou en utilsant unee map de donn�es.
 * 
 * (http://www.cs.waikato.ac.nz/ml/index.html)
 * 
 * @author Yannis BENDI-OUIS
 * @author Victor CONNES
 * @author Lucas GAMEZ
 * @author Jim PETIOT
 * 
 *
 */
@SuppressWarnings("serial")
public class SolarPanelSimulator implements Serializable {
	// https://weka.wikispaces.com/Serialization
	// private Instances practiceBase;
	private Classifier simulator;
	private String gessCol;
	public ArrayList<Double> orig = new ArrayList<Double>();

	private SolarPanelSimulator(String filePath) throws Exception {

		BufferedReader reader = new BufferedReader(new FileReader(filePath));
		Instances practiceBase = new Instances(reader);
		reader.close();

		// setting class attribute
		practiceBase.setClassIndex(practiceBase.numAttributes() - 1);
		String[] options = new String[2];
		options[0] = "-R";
		options[1] = "1";
		Remove remove = new Remove();
		remove.setOptions(options);
		remove.setInputFormat(practiceBase);
		Instances dataBase = Filter.useFilter(practiceBase, remove);
		//Instances dataBase = practiceBase;
		simulator = new MultilayerPerceptron();
		simulator.buildClassifier(dataBase);
		gessCol = "";
	}

	/**
	 * Cr�er un simulateur en utilisant un fichier .ser comme base
	 * d'apprentissage
	 * 
	 * @param dataPath
	 *            chemin du fichier .ser
	 * @return
	 * @throws Exception
	 */
	public static SolarPanelSimulator createSimulator(String dataPath)
			throws Exception {
		return createSimulator(dataPath, "", false);
	}

	/**
	 * Cr�er un simulateur en utilisant un fichier .ser comme base
	 * d'apprentissage
	 * 
	 * @param dataPath
	 *            chemin du fichier .ser
	 * @param linear
	 *            Si true, les donn�es vont �tre filtr�es
	 * @return
	 * @throws Exception
	 */
	public static SolarPanelSimulator createSimulator(String dataPath,
			boolean linear) throws Exception {
		return createSimulator(dataPath, "", linear);
	}

	/**
	 * Cr�er un simulateur en utilisant un fichier .ser comme base
	 * d'apprentissage
	 * 
	 * @param dataPath
	 *            chemin du fichier .ser
	 * @param colname
	 *            nom de la colonne dont les valeurs vont �tre simul�es
	 * @param linear
	 *            Si true, les donn�es vont �tre filtr�es
	 * @return simulator
	 * @throws Exception
	 */
	public static SolarPanelSimulator createSimulator(String dataPath,
			String colname, boolean linear) throws Exception {
		new File("SolarPanelSimulator/tmpDataCricket2017.arff").createNewFile();
		OpenData.createARFF(dataPath,
				"SolarPanelSimulator/tmpDataCricket2017.arff", colname, linear);
		SolarPanelSimulator ret = new SolarPanelSimulator(
				"SolarPanelSimulator/tmpDataCricket2017.arff");
		new File("SolarPanelSimulator/tmpDataCricket2017.arff").delete();
		ret.gessCol = colname;
		return ret;
	}

	/**
	 * 
	 * @param data
	 *            map de donn�es
	 * @return
	 * @throws Exception
	 */
	public static SolarPanelSimulator createSimulator(
			HashMap<Integer, Map<String, Double>> data) throws Exception {
		return createSimulator(data, "", false);
	}

	/**
	 * Cr�er un simulateur en utilisant une map de donn�es comme base
	 * d'apprentissage
	 * 
	 * @param data
	 *            map de donn�es
	 * @param linear
	 *            Si true, les donn�es vont �tre filtr�es
	 * @return
	 * @throws Exception
	 */
	public static SolarPanelSimulator createSimulator(
			HashMap<Integer, Map<String, Double>> data, boolean linear)
			throws Exception {
		return createSimulator(data, "", linear);
	}

	/**
	 * Cr�er un simulateur en utilisant une map de donn�es comme base
	 * d'apprentissage
	 * 
	 * @param data
	 *            map de donn�es
	 * @param colname
	 *            nom de la colonne dont les valeurs vont �tre simul�es
	 * @param linear
	 *            Si true, les donn�es vont �tre filtr�es
	 * @return simulator
	 * @throws Exception
	 */
	public static SolarPanelSimulator createSimulator(
			HashMap<Integer, Map<String, Double>> data, String colname,
			boolean linear) throws Exception {
		new File("SolarPanelSimulator/tmpDataCricket2017.arff").createNewFile();
		OpenData.createARFF(data,
				"SolarPanelSimulator/tmpDataCricket2017.arff", colname, linear);
		SolarPanelSimulator ret = new SolarPanelSimulator(
				"SolarPanelSimulator/tmpDataCricket2017.arff");
		new File("SolarPanelSimulator/tmpDataCricket2017.arff").delete();
		ret.gessCol = colname;
		return ret;
	}

	/**
	 * Enregistre le simulateur dans le fichier sp�cifier sous la forme d'un
	 * fichier .model
	 * 
	 * @param modelPath
	 * @throws IOException
	 */
	public void saveSimulator(String modelPath) throws IOException {
		ObjectOutputStream oos = null;
		final FileOutputStream fichier = new FileOutputStream(modelPath);
		oos = new ObjectOutputStream(fichier);
		oos.writeObject(this);
		oos.flush();
		oos.close();

	}

	/**
	 * Charge un model de SolarPanelSimulator.
	 * 
	 * @param pathfile
	 *            chemin d'acc�s du fichier .model
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public static SolarPanelSimulator loadSimulator(String pathfile)
			throws FileNotFoundException, IOException, ClassNotFoundException {
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(
				pathfile));
		SolarPanelSimulator sim = (SolarPanelSimulator) ois.readObject();
		ois.close();

		return sim;
	}

	/**
	 * Lance la simulation en utilisant un fichier .ser comme base de test
	 * 
	 * @param filePath
	 * @throws Exception
	 */
	public void simulate(String filePath) throws Exception {

		OpenData.createARFF(filePath,
				"SolarPanelSimulator/tmpDataCricket2017.arff", gessCol, false);

		BufferedReader reader = new BufferedReader(new FileReader(
				"SolarPanelSimulator/tmpDataCricket2017.arff"));
		Instances testBase = new Instances(reader);
		reader.close();
		new File("SolarPanelSimulator/tmpDataCricket2017.arff").delete();

		// setting class attribute
		testBase.setClassIndex(testBase.numAttributes() - 1);
		Instances resolv = new Instances(testBase);
		String[] options = new String[2];
		options[0] = "-R";
		options[1] = "1";
		Remove remove = new Remove();
		remove.setOptions(options);
		remove.setInputFormat(testBase);
		Instances dataBase = Filter.useFilter(testBase, remove);
		
		for (int i = 0; i < dataBase.numInstances(); i++) {
			double pred = simulator.classifyInstance(dataBase.instance(i));
			resolv.instance(i).setClassValue(pred);

			double cold = dataBase.instance(i).classValue();
			double cnew = resolv.instance(i).classValue();
			System.out.println(dataBase.instance(i).classValue() + " <=> "
					+ resolv.instance(i).classValue() + " .... "
					+ Math.abs(cold - cnew) / cold);

		}

	}

	/**
	 * Lance la simulation en utilisant une map de donn�es comme base de test
	 * 
	 * @param data
	 * @throws Exception
	 */
	public Map<Integer, Map<String, Double>> simulate(HashMap<Integer, Map<String, Double>> data)
			throws Exception {

		Map<Integer, Map<String, Double>> gessData = new HashMap<Integer, Map<String, Double>>();
		int key = 0;
		
		OpenData.createARFF(data,
				"SolarPanelSimulator/tmpDataCricket2017.arff", gessCol, false);

		BufferedReader reader = new BufferedReader(new FileReader(
				"SolarPanelSimulator/tmpDataCricket2017.arff"));
		Instances testBase = new Instances(reader);
		reader.close();
		new File("SolarPanelSimulator/tmpDataCricket2017.arff").delete();

		// setting class attribute
		testBase.setClassIndex(testBase.numAttributes() - 1);
		Instances resolv = new Instances(testBase);
		String[] options = new String[2];
		options[0] = "-R";
		options[1] = "1";
		Remove remove = new Remove();
		remove.setOptions(options);
		remove.setInputFormat(testBase);
		Instances dataBase = Filter.useFilter(testBase, remove);
		//Instances dataBase = testBase;
		for (int i = 0; i < dataBase.numInstances(); i++) {
			double pred = simulator.classifyInstance(dataBase.instance(i));
			resolv.instance(i).setClassValue(pred);
			Map<String, Double> instance = new HashMap<String, Double>();
			 List<String> parametre = OpenData.getListParam(gessCol);
			 key = (int) Math.round(resolv.instance(i).value(0));
			 for(int j=1; j<parametre.size() && j<resolv.instance(i).numValues();j++){
				 instance.put(parametre.get(j), resolv.instance(i).value(j));
			 }
			 instance.put("RENDEMENT", resolv.instance(i).classValue());
			 gessData.put(key, instance);
			 key++;

		}
		return gessData;

	}

	/**
	 * 
	 * Lance la simulation en utilisant un fichier .arff comme base de test
	 * 
	 * @param filePath
	 * @throws Exception
	 */
	@Deprecated
	public ArrayList<Double> simulateWithARFF(String filePath) throws Exception {
		Map<Integer, Map<String, Double>> gessData = new HashMap<Integer, Map<String, Double>>();
		int key = 0;
		
		BufferedReader reader = new BufferedReader(new FileReader(filePath));
		Instances testBase = new Instances(reader);
		reader.close();

		// setting class attribute
		testBase.setClassIndex(testBase.numAttributes() - 1);
		// !\\ Peut �tre qu'une �ventuelle erreur vien de l� (il faudrait mettre
		// attribu de l'instanes d'apprentissage -1))
		Instances resolv = new Instances(testBase);
		ArrayList<Double> ret = new ArrayList<Double>();
		orig = new ArrayList<Double>();
		for (int i = 0; i < testBase.numInstances(); i++) {
			double pred = simulator.classifyInstance(testBase.instance(i));
			resolv.instance(i).setClassValue(pred);

			double cold = testBase.instance(i).classValue();
			double cnew = resolv.instance(i).classValue();
			ret.add(cnew);
			orig.add(cold);

			 Map<String, Double> instance = new HashMap<String, Double>();
			 List<String> parametre = OpenData.getListParam(gessCol);
			 for(int j=0; j<parametre.size() && j<testBase.instance(i).numValues();j++){
				 instance.put(parametre.get(j), testBase.instance(i).value(j));
			 }
			 gessData.put(key, instance);
			 key++;

		}
		return ret;
	}
}
