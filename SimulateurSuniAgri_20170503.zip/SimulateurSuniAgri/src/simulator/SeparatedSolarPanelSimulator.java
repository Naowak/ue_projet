package simulator;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * SeparatedSolarPanelSimulator est une class boite noire qui cr�er et utilise le model
 * MultilayerPerceptron de Weka. Lors de son utilisation, cette classe va s�parer les donn�es 
 * pour lesquelles les brumisateur sont activ�s et celles o� les brumisateurs sont d�sactiv�s
 * 
 * (http://www.cs.waikato.ac.nz/ml/index.html)
 * 
 * @author Yannis BENDI-OUIS
 * @author Victor CONNES
 * @author Lucas GAMEZ
 * @author Jim PETIOT
 * 
 *
 */
@SuppressWarnings("serial")
public class SeparatedSolarPanelSimulator  implements Serializable {
	SolarPanelSimulator activated;
	SolarPanelSimulator desactivated;
	
	private SeparatedSolarPanelSimulator(
			HashMap<Integer, Map<String, Double>> dataActivated,
			HashMap<Integer, Map<String, Double>> dataDesactivated,
			String colname, boolean linear) throws Exception {
		activated = SolarPanelSimulator.createSimulator(dataActivated, colname, linear);
		desactivated = SolarPanelSimulator.createSimulator(dataDesactivated, colname, linear);
		
	}
	
	/**
	 * 
	 * @param data
	 *            map de donn�es
	 * @return
	 * @throws Exception
	 */
	public static SeparatedSolarPanelSimulator createSimulator(HashMap<Integer, Map<String, Double>> data) throws Exception{
		return SeparatedSolarPanelSimulator.createSimulator(data,false);
		
	}

	/**
	 * Cr�er un simulateur en utilisant une map de donn�es comme base
	 * d'apprentissage
	 * 
	 * @param data
	 *            map de donn�es
	 * @param linear
	 *            Si true, les donn�es vont �tre filtr�es
	 * @return
	 * @throws Exception
	 */
	public static SeparatedSolarPanelSimulator createSimulator(
			HashMap<Integer, Map<String, Double>> data, boolean linear) throws Exception {
		return SeparatedSolarPanelSimulator.createSimulator(data,"",linear);
	}

	/**
	 * Cr�er un simulateur en utilisant une map de donn�es comme base
	 * d'apprentissage
	 * 
	 * @param data
	 *            map de donn�es
	 * @param colname
	 *            nom de la colonne dont les valeurs vont �tre simul�es
	 * @param linear
	 *            Si true, les donn�es vont �tre filtr�es
	 * @return simulator
	 * @throws Exception
	 */
	private static SeparatedSolarPanelSimulator createSimulator(
			HashMap<Integer, Map<String, Double>> data, String colname,
			boolean linear) throws Exception {
		HashMap<Integer, Map<String, Double>> dataA = new HashMap<Integer, Map<String, Double>>();
		HashMap<Integer, Map<String, Double>> dataD = new HashMap<Integer, Map<String, Double>>();
		DataWork.separation_data_brumisateur(data, dataA, dataD);
		return new SeparatedSolarPanelSimulator(dataA, dataD, colname, linear);
	}
	
	/**
	 * Enregistre le simulateur dans le fichier sp�cifier sous la forme d'un
	 * fichier .model
	 * 
	 * @param modelPath
	 * @throws IOException
	 */
	public void saveSimulator(String modelPath) throws IOException {
		ObjectOutputStream oos = null;
		final FileOutputStream fichier = new FileOutputStream(modelPath);
		oos = new ObjectOutputStream(fichier);
		oos.writeObject(this);
		oos.flush();
		oos.close();

	}
	
	/**
	 * Charge un model de SeparatedSolarPanelSimulator.
	 * 
	 * @param pathfile
	 *            chemin d'acc�s du fichier .model
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public static SeparatedSolarPanelSimulator loadSimulator(String pathfile)
			throws FileNotFoundException, IOException, ClassNotFoundException {
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(
				pathfile));
		SeparatedSolarPanelSimulator sim = (SeparatedSolarPanelSimulator) ois.readObject();
		ois.close();

		return sim;
	}
	
	/**
	 * Lance la simulation en utilisant une map de donn�es comme base de test
	 * 
	 * @param data
	 * @throws Exception
	 */
	public Map<Integer, Map<String, Double>> simulate(HashMap<Integer, Map<String, Double>> data)
			throws Exception {
		Map<Integer, Map<String, Double>> ret = new HashMap<Integer, Map<String, Double>>();
		HashMap<Integer, Map<String, Double>> dataA = new HashMap<Integer, Map<String, Double>>();
		HashMap<Integer, Map<String, Double>> dataD = new HashMap<Integer, Map<String, Double>>();
		DataWork.separation_data_brumisateur(data, dataA, dataD);
		
		ret.putAll(activated.simulate(dataA));
		ret.putAll(desactivated.simulate(dataD));
		
		
		return ret;
	}
}
