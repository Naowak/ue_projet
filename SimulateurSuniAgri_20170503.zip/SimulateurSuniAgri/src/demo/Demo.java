package demo;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.HashMap;
import java.util.Map;

import simulator.SolarPanelSimulator;


public class Demo {

	public static void main(String[] args) {
		FileInputStream fis;
		try {
			fis = new FileInputStream("SolarPanelSimulator/data/hashmap.ser");

			ObjectInputStream ois = new ObjectInputStream(fis);
			@SuppressWarnings("unchecked")
			HashMap<Integer, Map<String, Double>> dataTot = (HashMap<Integer, Map<String, Double>>) ois
					.readObject();
			ois.close();
			
			for(int k : dataTot.keySet()){
				if(dataTot.get(k).containsKey("VENT"))
					dataTot.get(k).remove("VENT");
				if(dataTot.get(k).containsKey("WSPD"))
					dataTot.get(k).remove("WSPD");
				if(dataTot.get(k).containsKey("LW1"))
					dataTot.get(k).remove("LW1");
			}
			
			int dixP = dataTot.size()*10/100;
			HashMap<Integer, Map<String, Double>> data = new HashMap<Integer, Map<String, Double>>();
			HashMap<Integer, Map<String, Double>> dataSim = new HashMap<Integer, Map<String, Double>>();
			for(int k : dataTot.keySet()){
				if(dixP>0){
					dataSim.put(k, dataTot.get(k));
					dixP--;
				}else{
					data.put(k, dataTot.get(k));
				}
			}
			
			
			/***********************************************/
			boolean load = true;
			//Apprentissage du model (ou chargement d'un model existant)
			SolarPanelSimulator s1 = null;
			if(!load){
				s1 = SolarPanelSimulator.createSimulator(data);
				s1.saveSimulator("SolarPanelSimulator/models/demo.model");
			}else{
				s1 = SolarPanelSimulator.loadSimulator("SolarPanelSimulator/models/demo.model");
			}
			/***********************************************/
			
			
			double oldMoy = 0.0;
			Map<Integer, Double> rent = new HashMap<Integer, Double>();
			for(int k : dataSim.keySet()){
				if(dataSim.get(k).containsKey("P_01") && dataSim.get(k).containsKey("P_02") && dataSim.get(k).containsKey("P_03")){
					rent.put(k, dataSim.get(k).get("P_01")+dataSim.get(k).get("P_02")+dataSim.get(k).get("P_03"));
					oldMoy = oldMoy + dataSim.get(k).get("P_01")+dataSim.get(k).get("P_02")+dataSim.get(k).get("P_03");
				}
			}
			
			//Simulation
			Map<Integer, Map<String, Double>> gess = s1.simulate(dataSim);
			//Affichage
			double newMoy = 0.0;
			double ecart = 0.0;
			int numData = 0;
			for(int k : gess.keySet()){
				newMoy = newMoy + gess.get(k).get("RENDEMENT");
				if(rent.containsKey(k)){
					System.out.println(rent.get(k) + " - " + gess.get(k).get("RENDEMENT") + " = " + Math.abs(rent.get(k)-gess.get(k).get("RENDEMENT")));
					ecart += Math.abs(rent.get(k)-gess.get(k).get("RENDEMENT"));
					numData++;
				}
			}
			oldMoy = oldMoy/gess.size();
			newMoy = newMoy/gess.size();
			System.out.println("Moyenne de rendement data : " + oldMoy);
			System.out.println("Moyenne de rendement gess : " + newMoy);
			System.out.println("Ecart total : " + ecart);
			System.out.println("Ecart moyen : " + ecart/numData);
			System.out.println(dataSim.size() + " - " + gess.size());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}

}
