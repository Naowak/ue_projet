package simulator;
import java.io.*;
import java.util.*;
import java.util.Map.Entry;
import java.text.*;

/**
 * Ce fichier contient les m�thode permettant de cr�er les fichiers de donn�es
 * qui sont utilis�s par Weka
 **/
public class OpenData {
	public static void main(String[] args) throws Exception {
		if (args.length != 1) {
			System.out.println("Usage : <file_name_out>");
			System.exit(1);
		}
		try {
			FileInputStream fis = new FileInputStream("SolarPanelSimulator/data/hashmap.ser");
			ObjectInputStream ois = new ObjectInputStream(fis);
			@SuppressWarnings("unchecked")
			HashMap<Integer, Map<String, Double>> data = (HashMap<Integer, Map<String, Double>>) ois
					.readObject();
			ois.close();

			List<String> parametres = input_parameters();
			parse_and_write(args[0], data, parametres);

		} catch (IOException ioe) {
			System.out.println(ioe);
		}

	}

	/**
	 * Cr�� un fichier ARFF contenant les donn�es contenues dans le fichier
	 * pass� en param�tre.
	 * 
	 * @param dataPath
	 *            chemin du fichier .ser contenant les donn�es
	 * @param file_name
	 *            Nom du fichier .arff qui va �tre cr��
	 * @param colname
	 *            Nom de la colonne qui sera
	 * @param linear
	 *            Si true, les donn�es vont �tre filtr�es
	 * @throws Exception
	 */
	public static void createARFF(String dataPath, String file_name,
			String colname, boolean linear) throws Exception {

		FileInputStream fis = new FileInputStream(dataPath);
		ObjectInputStream ois = new ObjectInputStream(fis);
		@SuppressWarnings("unchecked")
		HashMap<Integer, Map<String, Double>> data = (HashMap<Integer, Map<String, Double>>) ois
				.readObject();
		ois.close();

		List<String> parametres = input_parameters(colname);
		if (linear) {
			data = filtre_passe_bas_data(data, parametres);
		}
		parse_and_write(file_name, data, parametres);

	}

	/**
	 * Cr�� un fichier ARFF contenant les donn�es contenues dans le fichier
	 * pass� en param�tre.
	 * 
	 * @param data
	 *            HashMap contenant les donn�es
	 * @param file_name
	 *            Nom du fichier .arff qui va �tre cr��
	 * @param colname
	 *            Nom de la colonne qui sera
	 * @param linear
	 *            Si true, les donn�es vont �tre filtr�es
	 * @throws Exception
	 */
	public static void createARFF(HashMap<Integer, Map<String, Double>> data,
			String file_name, String colname, boolean linear) throws Exception {

		List<String> parametres = input_parameters(colname);
		if (linear) {
			data = filtre_passe_bas_data(data, parametres);
		}
		parse_and_write(file_name, data, parametres);

	}

	/**
	 * @return
	 */
	public static List<String> input_parameters() {
		List<String> parametre = new ArrayList<String>();
		parametre.add("ID");
		parametre.add("TIME");
		parametre.add("CPT_DEBI");
		parametre.add("TEMPERATURE");
		parametre.add("DRAI");
		parametre.add("PYRA");
		parametre.add("VENT");
		parametre.add("TAIR");
		// parametre.add("RAIN");
		parametre.add("Z_01");
		parametre.add("Z_02");
		parametre.add("Z_03");
		parametre.add("Z_04");
		parametre.add("Z_05");
		parametre.add("L_W1");
		parametre.add("T_W1");
		parametre.add("T_04");
		parametre.add("T_03");
		parametre.add("T_02");
		parametre.add("T_01");
		parametre.add("T_05");
		parametre.add("WSPD");
		parametre.add("CONDITION");
		parametre.add("UP01");
		parametre.add("PMP1");
		// parametre.add("P_01");
		// parametre.add("P_02");
		// parametre.add("P_03");
		parametre.add("RENDEMENT");
		for (int i = 0; i < parametre.size(); ++i) {
			System.out.println(i + " : " + parametre.get(i));
		}

		BufferedReader console = new BufferedReader(new InputStreamReader(
				System.in));
		System.out
				.println("Donnez les param�tres souhait�s : nb1 nb2 nb3 nb4 ...\n");
		String input;
		try {
			input = console.readLine();
		} catch (IOException e) {
			System.out
					.println("Un probl�me est survenu lors de la saisie. Ordre par d�fault utilis�");
			input = "1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24";
		}

		String[] p = input.split(" ");
		List<String> retour = new ArrayList<String>();
		for (int i = 0; i < p.length; ++i) {
			retour.add(parametre.get(Integer.parseInt(p[i])));
		}
		return retour;
	}

	/**
	 * @param colname
	 * @return
	 */
	public static List<String> input_parameters(String colname) {
		List<String> parametre = new ArrayList<String>();
		parametre.add("ID");
		parametre.add("TIME");
		parametre.add("CPT_DEBI");
		parametre.add("TEMPERATURE");
		parametre.add("DRAI");
		parametre.add("PYRA");
		parametre.add("VENT");
		parametre.add("TAIR");
		// parametre.add("RAIN");
		parametre.add("Z_01");
		parametre.add("Z_02");
		parametre.add("Z_03");
		parametre.add("Z_04");
		parametre.add("Z_05");
		parametre.add("L_W1");
		parametre.add("T_W1");
		parametre.add("T_04");
		parametre.add("T_03");
		parametre.add("T_02");
		parametre.add("T_01");
		parametre.add("T_05");
		parametre.add("WSPD");
		parametre.add("CONDITION");
		parametre.add("UP01");
		parametre.add("PMP1");
		// parametre.add("P_01");
		// parametre.add("P_02");
		// parametre.add("P_03");
		parametre.add("RENDEMENT");

		if (parametre.remove(colname))
			parametre.add(colname);

		String input = "0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24";
		String[] p = input.split(" ");
		List<String> retour = new ArrayList<String>();
		for (int i = 0; i < p.length; ++i) {
			retour.add(parametre.get(Integer.parseInt(p[i])));
		}
		return retour;
	}

	/**
	 * M�thode qui cr�er un fichier .arff pr�t � �tre utilis� par la biblioth�que weka
	 * @param name_file
	 * @param data
	 * @param parametre
	 * @throws Exception
	 */
	public static void parse_and_write(String name_file,
			HashMap<Integer, Map<String, Double>> data, List<String> parametre)
			throws Exception {
		// On prépare le fichier dans lequel on écrit

		PrintWriter writer = new PrintWriter(name_file, "UTF-8");

		writer.println("@relation SuniAgri");
		writer.println("");

		int nb_parametre = parametre.size();

		for (int i = 0; i < nb_parametre; ++i)
			writer.println("@attribute " + parametre.get(i) + " numeric");

		writer.println("");
		writer.println("@data");

		// for(HashMap.Entry<Integer, Map<String, Double>> entry :
		// data.entrySet())

		for (Entry<Integer, Map<String, Double>> entry : data.entrySet()) {
			String separateur = "";
			for (int i = 0; i < nb_parametre; ++i) {
				if (parametre.get(i) == "TIME") {
					// Parametre TIME
					long time = entry.getKey();
					Date date = new Date(time * 1000);
					DateFormat formatter = new SimpleDateFormat("HH:mm:ss");
					String dateFormatted = formatter.format(date);
					int hours = Integer.parseInt(dateFormatted.substring(0, 2));
					int minutes = Integer.parseInt(dateFormatted
							.substring(3, 5));
					int seconds = Integer.parseInt(dateFormatted
							.substring(6, 8));
					int day_time = hours * 3600 + minutes * 60 + seconds;
					writer.print(separateur + day_time);
				} else if (parametre.get(i) == "RENDEMENT") {
					// Parametre RENDEMENT
					try {
						double r = entry.getValue().get("P_01")
								+ entry.getValue().get("P_02")
								+ entry.getValue().get("P_03");
						writer.print(separateur + r);
					} catch (NullPointerException e) {
						writer.print(separateur + "?");
					}
				} else if (parametre.get(i) == "ID"){
					writer.print(separateur + entry.getKey());
				} else {
					try {
						if (entry.getValue().get(parametre.get(i)) == null) {
							throw new NullPointerException();
						}
						writer.print(separateur
								+ entry.getValue().get(parametre.get(i)));
					} catch (NullPointerException e) {
						writer.print(separateur + "?");
					}
				}
				separateur = ",";
			}
			writer.println("");
		}

		writer.close();

	}

	/**
	 * M�thode permettant de lisser des donn�es en vu de r�duire le bruit.
	 * @param data
	 * @param param
	 * @return
	 */
	public static HashMap<Integer, Map<String, Double>> filtre_passe_bas_data(HashMap<Integer, Map<String, Double>> data, List<String> param) {
		/* HashMap<Integer, Map<String, Double>> data : donn�es bruit�es sous forme de HashMap
		List<String> param : Liste des param�tres demand�s */

		//Cr�ation du filtre 	
		int filtre[] = {1, 2, 3, 4, 5, 6, 7, 8, 68, 8, 7, 6, 5, 4, 3, 2, 1};

		int coef = 0;
		for(int i= 0; i < filtre.length; ++i)
			coef += filtre[i];


		HashMap<Integer, Map<String, Double>> new_data = new HashMap<Integer, Map<String, Double>>();
		int nb_param = param.size();
		int nb_data = data.size();
		//Les donn�es �tant stock�s dans un map, elles ne sont pas mises dans l'ordre, il faut donc
		//les tri�es selon le timestamp
		Integer keys[] = data.keySet().toArray(new Integer[nb_data]);
		Arrays.sort(keys);

		//Pour chaque dimension
		for(int i = 0; i < nb_param; ++i){
			//On r�cup�re les param�tres demand�s, et on g�re les param�tres "multi-colonnes"
			String p = param.get(i);
			List<String> ps = new ArrayList<String>();
			int taille_ps = 0;
			if(p == "RENDEMENT"){
				//Le param�tre rendement correspond � trois param�tres de la map
				//(P_01, P_02, P_03)
				ps.add("P_01");
				ps.add("P_02");
				ps.add("P_03");
				taille_ps = 3;
			}
			else{
				ps.add(p);
				taille_ps = 1;
			}

			//Dans le cas o� le param�tre demand� est r�parti sur plusieurs param�tre de la map 
			//(exemple le rendement, qui est sur trois param�tre : P_01, P_02, P_03)
			//On tourne sur chacun d'entre eux (la ArrayList ps)
			for(int cmp = 0; cmp < taille_ps; ++cmp){
				p = ps.get(cmp);

				int debut_parcours_data = filtre.length/2;
				int fin_parcours_data = nb_data - filtre.length/2;
				//On parcours les donn�es (on fait gaffe aux extr�mit�s sur lesquelles le filtre 
				//ne peut �tre appliqu�, sinon d�passement de tableau)
				for(int j = debut_parcours_data; j < fin_parcours_data; ++j){
					if(new_data.get(keys[j]) == null){
					//Si new_data n'existe pas encore pour le timestamp j, on le cr�er
						new_data.put(keys[j], new HashMap<String, Double>());
					}
					double new_value = 0;
					int debut_k = -filtre.length/2;
					int fin_k = filtre.length - filtre.length/2;
					for(int k = debut_k; k < fin_k; ++k){
						//pour tous les k points avant et apr�s, on fait la somme pond�r�e
						try{
							new_value += data.get(keys[j+k]).get(p)*filtre[k+10];
						}
						catch(Exception e){
							//Dans le cas o� la donn�e est manquante
							new_value += 0;
						}
					}
					//On calcule la moyenne
					new_value = new_value / coef;
					//On met la moyenne dans new_data
					new_data.get(keys[j]).put(p, new_value);
				}
			}
		}
		return new_data;
	}
	/*public static HashMap<Integer, Map<String, Double>> filtre_passe_bas_data(
			HashMap<Integer, Map<String, Double>> data, List<String> param) {
		int filtre[] = { 1, 2, 1 };
		int coef = 4;

		HashMap<Integer, Map<String, Double>> new_data = new HashMap<Integer, Map<String, Double>>();

		int nb_param = param.size();
		int nb_data = data.size();

		Integer keys[] = data.keySet().toArray(new Integer[nb_data]);
		Arrays.sort(keys);

		for (int i = 0; i < nb_param; ++i) {
			// Pour chaque param�tre
			String p = param.get(i);
			List<String> ps = new ArrayList<String>();
			int taille_ps = 0;
			if (p == "RENDEMENT") {
				ps.add("P_01");
				ps.add("P_02");
				ps.add("P_03");
				taille_ps = 3;
			} else {
				ps.add(p);
				taille_ps = 1;
			}
			for (int cmp = 0; cmp < taille_ps; ++cmp) {
				p = ps.get(cmp);
				for (int j = 10; j < nb_data - 10; ++j) {
					// Pour chaque donn�e
					if (new_data.get(keys[j]) == null) {
						// Si new_data n'existe pas encore pour le timestamp j,
						// on le cr�er
						new_data.put(keys[j], new HashMap<String, Double>());
					}
					double new_value = 0;
					for (int k = -10; k < 11; ++k) {
						// pour tous les points autours, on fait la somme
						// pond�r�
						try {
							new_value += data.get(keys[j + k]).get(p)
									* filtre[k + 10];
						} catch (Exception e) {
							new_value += 0;
						}
						// System.out.println(data.get(keys[j+k]).get(p)*filtre[k+10]);
					}
					// On calcule la moyenne
					new_value = new_value / coef;
					// On met la moyenne dans new_data
					new_data.get(keys[j]).put(p, new_value);
				}
			}
		}
		return new_data;
	}*/

	public static List<String> getListParam(String gessCol) {
		List<String> parametre = new ArrayList<String>();
		parametre.add("ID");
		parametre.add("TIME");
		parametre.add("CPT_DEBI");
		parametre.add("TEMPERATURE");
		parametre.add("DRAI");
		parametre.add("PYRA");
		parametre.add("VENT");
		parametre.add("TAIR");
		// parametre.add("RAIN");
		parametre.add("Z_01");
		parametre.add("Z_02");
		parametre.add("Z_03");
		parametre.add("Z_04");
		parametre.add("Z_05");
		parametre.add("L_W1");
		parametre.add("T_W1");
		parametre.add("T_04");
		parametre.add("T_03");
		parametre.add("T_02");
		parametre.add("T_01");
		parametre.add("T_05");
		parametre.add("WSPD");
		parametre.add("CONDITION");
		parametre.add("UP01");
		parametre.add("PMP1");
		// parametre.add("P_01");
		// parametre.add("P_02");
		// parametre.add("P_03");
		parametre.add("RENDEMENT");

		if (parametre.remove(gessCol))
			parametre.add(gessCol);

		return parametre;
	}
}