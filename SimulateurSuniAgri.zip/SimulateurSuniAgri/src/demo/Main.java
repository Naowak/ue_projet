package demo;
import java.io.File;
import java.util.ArrayList;
import simulator.SolarPanelSimulator;


public class Main {

	public static void main(String[] args) {
		try {
			/*SolarPanelSimulator s = new SolarPanelSimulator("arffFiles/test1.arff");
			//SolarPanelSimulator s = SolarPanelSimulator.createSimulator("data/hashmap.ser");
			//s.simulateWithARFF("arffFiles/test2.arff");

			s.simulateWithARFF("arffFiles/test2.arff");
			s.saveSimulator("model1");*/
			//SolarPanelSimulator sL = SolarPanelSimulator.createSimulator("SolarPanelSimulator/data/hashmap.ser",true);
			//sL.saveSimulator("SolarPanelSimulator/models/filtre1.model");
			//SolarPanelSimulator sL2 = SolarPanelSimulator.createSimulator("SolarPanelSimulator/data/hashmap.ser",false);
			//sL2.saveSimulator("SolarPanelSimulator/models/data.model");
			SolarPanelSimulator sL = SolarPanelSimulator.loadSimulator("SolarPanelSimulator/models/filtre1.model");
			SolarPanelSimulator sL2 = SolarPanelSimulator.loadSimulator("SolarPanelSimulator/models/data.model");
			
			ArrayList<Double> rL = sL.simulateWithARFF("SolarPanelSimulator/arffFiles/test2.arff");
			ArrayList<Double> rNL = sL2.simulateWithARFF("SolarPanelSimulator/arffFiles/test2.arff");
			ArrayList<Double> l = sL.orig;
			
			double s1 = 0.0,s2 = 0.0;
			
			for(int i =0; i<l.size();i++){
				//System.out.println(l.get(i) + " : " + rNL.get(i) + " | " + rL.get(i));
				//System.out.println(Math.abs(l.get(i) - rNL.get(i)) / l.get(i) + " | " + Math.abs(l.get(i) - rL.get(i)) / l.get(i));
				s1 += Math.abs(l.get(i)-rNL.get(i));
				s2 += Math.abs(l.get(i)-rL.get(i));
			}
			System.out.println("\nNombre de donn�es simul�es : " + l.size());
			System.out.println("Ecart cumul� : " + s1 + " | " + s2);
			System.out.println("Ecart moyen : " + s1/l.size() + " | " + s2/l.size());
			
			
			//s.simulateWithARFF("arffFiles/test2.arff");
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}

}
